
from ..enums import EntityDirection

"""
The engine class handles physics and movement validation.
"""


class Engine:
    def __init__(self, grid: list[list[int]]) -> None:
        self.grid = grid
        self.opposite_bits = {
            1: 4,
            2: 8,
            4: 1,
            8: 2,
        }
        self.bit_direction = {
            (0, -1): 8,
            (1, 0): 4,
            (0, 1): 2,
            (-1, 0): 1,
        }

    @property
    def width(self) -> int:
        return len(self.grid[0])

    @property
    def height(self) -> int:
        return len(self.grid)

    def get_valid_position(
        self, case: tuple[int, int]
    ) -> list[EntityDirection]:
        valid_neighbour_list = []
        for direction in EntityDirection:
            if self.is_valid_position(direction.value, case):
                valid_neighbour_list.append(direction)
        return valid_neighbour_list

    def is_valid_position(
        self,
        direction: tuple[int, int],
        case: tuple[int, int],
    ) -> bool:
        cy, cx = case
        dir_y, dir_x = direction
        next_case = (cy + dir_y, cx + dir_x)
        ncy, ncx = next_case
        bits = self.bit_direction[direction]

        return (
            self.is_in_grid(next_case)
            and not self._is_wall(self.grid[cy][cx], bits)
            and not self._is_wall(
                self.grid[ncy][ncx],
                self._opposite_wall(bits),
            )
        )

    def _opposite_wall(self, bits_current_case: int) -> int:
        return self.opposite_bits[bits_current_case]

    def _is_wall(self, case_value: int, bits: int) -> bool:
        return (case_value & bits) != 0

    def is_in_grid(self, case: tuple[int, int]) -> bool:
        y, x = case
        return (
            x >= 0
            and x < self.width
            and y >= 0
            and y < self.height
        )
